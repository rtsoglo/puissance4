package Puissance4;



public class Application {

	public static void main(String[] args) {
	
		Controleur jeu = new Controleur(true);
		
		//Notre controleur de jeu fait appel a son modele et a la vue principale(Game_View)
		
		//la vue principale contient tous les elements graphiques
		// Game_View contient le plateau de jeu et les autres panneaux d'interactions
		
			
		}
}